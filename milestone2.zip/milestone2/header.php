<!DOCTYPE html>
<html>

<head>
    <title>Milestone3</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
    <center>
        <font size="20" color="black">Center for Applied Research in Information Technology</font>
    </center>

    <div class="topnav">
            <a class="active" href="index.html">Home</a>
            <a href="faculty.php">About</a>
            <a href="events.php">Events</a>
            <a href="evaluation.php">Evaluation</a>




    </div>

</body>


<body>

    <h1>
        <p>


            <center>
                <a href="https://ccse.kennesaw.edu/it/"><img src="Preview Image.jpg" width="200" height="200"> </a>
            </center>
        </p>
</body>
</html>