<!DOCTYPE html>
<html>

<head>
    <title>Faculty</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
    <center>
        <font size="20" color="black">Center for Applied Research in Information Technology</font>
    </center>

    <div class="topnav">
    <a class="active" href="index.html">Home</a>
            <a href="faculty.php">About</a>
            <a href="events.php">Events</a>
            <a href="evaluation.php">Evaluation</a>



    </div>



</body>



<body>

    <h1>
        <p>
            <center>
                <a href="https://ccse.kennesaw.edu/it/ "><img src="Preview Image.jpg " width="200" height="200 "> </a>
            </center>
        </p>
    </h1>


    <h3><ins><b>Le Li  <a href= "http://facultyweb.kennesaw.edu/lli13/index.php"style="color:gray">Website</a></b></ins></h3>
    <p>Dr. Lei Li is a professor and assistant chair at the Department of Information Technology. Dr. Li is also in charge of the Master 's Science in Information Technology program </p>
    <p><br> Phone: (470) 578-3915
        <br>Email: lli13@kennesaw.edu
        <br>Location: J 364</p>
    <p>Research interests: Social Media Data Analytics, Information Security, Web Information Management, IT Education</p>
    <img src=" http://facultyweb.kennesaw.edu/lli13/Li%20Headshot%20copy.jpg " style="width:200px ">

    <h3><ins><b>Hossain Shahriar <a href= "http://ksuweb.kennesaw.edu/~hshahria/research.php "style="color:gray ">Website</a></b></ins></h3>
    <p>Hossain Shahriar is an associate Professor & BSIT/BASIT Program Coordinator </p>
    <p><br> Phone: (470) 578-3866
        <br>Email:hshahria@kennesaw.edu
        <br>Location:J 336</p>
    <p>Research Interests: Mobile application, Health informatics and IT Education</p>
    <img src="https://ccse.kennesaw.edu/it/images/Hossain%20Shahriar.jpg " style="width:200px ">

    <h3><ins><b>Rich Halstead-Nussloch <a href= "http://ksuweb.kennesaw.edu/~rhalstea/ "style="color:gray ">Website</a></b></ins></h3>
    <p>Professor in the IT Department - School of Computing and Software Engineering </p>
    <p><br> Phone: (470) 578-5509
        <br>Email: rhalstea@kennesaw.edu
        <br>Location:J 361</p>
    <p>Research Interests: Mobile application, Health informatics and IT Education</p>
    <img src="https://ccse.kennesaw.edu/it/images/Rich%20HN.png " style="width:200px ">

</body>
<footer>

    <center>
        <ol>
            <br><b>Marietta Campus</b>
            <br>100 South Marietta Pkwy
            <br>Marietta, GA 30060
            <br>Phone: 470-578-6000
        </ol>

        <b> 2019 Kennesaw State University </b>
    </center>

    <center>
        <p>
            <B>This is a class project. <a href="http://it5443.azurewebsites.net/ ">link to this class </a></B>
        </p>
    </center>

</html>