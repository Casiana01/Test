<!DOCTYPE html>
<html>

<head>
    <title>Events</title>

    <link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>
    <center>
        <font size="20" color="black">Center for Applied Research in Information Technology</font>
    </center>
    <div class="topnav">
    <a class="active" href="index.html">Home</a>
            <a href="faculty.php">About</a>
            <a href="events.php">Events</a>
            <a href="evaluation.php">Evaluation</a>

</body>

<body>

    <style>
        table,
        th,
        td {
            border: 2px black;
        }
    </style>
</body>
<h1>
    <p>
        <center>
            <a href="https://ccse.kennesaw.edu/it/ "><img src="Preview Image.jpg " width="200" height="200 "> </a>
        </center>
    </p>
</h1>

<h4><ins><b>Events</b></ins></h4>

<table>
    <center>
        <tr>
            <th>Event Name</th>
            <th>Location</th>
        </tr>
        <tr>
            <td>Hackathon</td>
            <td>Marietta Campus</td>
        </tr>
        <tr>
            <td>Game Jam</td>
            <td>Marietta Campus</td>
        </tr>
        <tr>
            <td>Internship Networking</td>
            <td>Marietta Campus</td>
        </tr>
    </center>
</table>

<ul>
    <li><b>Hackathon:</b> the premier of the college event in showcasing student talent and connecting companies to our students. <a href="https://ccse.kennesaw.edu/news-events/hackathon-2019.php" style="color:gray">Read more</a></li>
    </li>
    <li><b>Game Jam:</b>a gathering for the purpose of planning, designing, and creating one or more games within a short span of time, usually ranging between 24 and 72 hours. <a href="https://ccse.kennesaw.edu/news-events/game-jam/index.php" style="color:gray">Read more</a></li>
    </li>
    <li><b>Internship Networking Event:</b> a flash networking event where students can connect with potential employers. <a href="https://ccse.kennesaw.edu/news-events/Internship-Networking-Night-Spring-2019.php" style="color:gray">Read more</a></li>
    </li>


</ul>

</body>
<footer>
    <center>
        <ol>
            <br><b>Marietta Campus</b>
            <br>100 South Marietta Pkwy
            <br>Marietta, GA 30060
            <br>Phone: 470-578-6000
        </ol>

        <b> 2019 Kennesaw State University </b>
    </center>

    <center>
        <p>
            <B>This is a class project. <a href="http://it5443.azurewebsites.net/">link to this class </a></B>
        </p>
    </center>

</html>