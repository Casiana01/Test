<html>
 
<?php include('header.php'); ?>


<?php if (isset($_POST['submit'])) ?>
<link rel="stylesheet" type="text/css" href="style.css">
<div style="text-align:center" class="center">
<table id="form" style="text-align:center">
<table align="center" width="1000" bgcolor="white
" border="5">
<th colspan="10" bgcolor="gold"><b>Form Applicant Information</b></th>

<tr><td>First Name:</td><td><?php echo $_POST['FName']?></td></tr>
<tr><td>Last Name:</td><td><?php echo $_POST['LName']?></td></tr>
<tr><td>Gender:</td><td><?php echo $_POST['gender']?></td></tr>
<tr><td>Skills:</td><td><?php echo $_POST['skills']?></td></tr>
<tr><td>Email:</td><td><?php echo $_POST['email']?></td></tr>
<tr><td>Status:</td><td><?php echo $_POST['status']?></td></tr>
<tr><td>Address:</td><td><?php echo $_POST['address']?></td></tr>
<tr><td>City:</td><td><?php echo $_POST['city']?></td></tr>
<tr><td>Zip Code:</td><td><?php echo $_POST['Zipcode']?></td></tr>
<tr><td>State:</td><td><?php echo $_POST['state']?></td></tr>
<tr><td>Country:</td><td><?php echo $_POST['country']?></td></tr>
<tr><td>Cummulative GPA:</td><td><?php echo $_POST['GPA']?></td></tr>
<tr><td>Major:</td><td><?php echo $_POST['Major']?></td></tr>
<tr><td>Prospective Graduation Date:</td><td><?php echo $_POST['GradDate']?></td></tr>
<tr><td>Student Signature:</td><td><?php echo $_POST['Signature']?></td></tr>
<tr><td>Date:</td><td><?php echo $_POST['Date']?></td></tr>

</table>

<footer>

<center>
    <ol>
        <br><b>Marietta Campus</b>
        <br>100 South Marietta Pkwy
        <br>Marietta, GA 30060
        <br>Phone: 470-578-6000
    </ol>

    <b> 2019 Kennesaw State University </b>
</center>
<center>
    <p>
        <B>This is a class project. <a href="http://it5443.azurewebsites.net/">link to this class </a></B>
    </p>
</center>

</footer>
