<footer>
    <center>
        <ol>
            <br><b>Marietta Campus</b>
            <br>100 South Marietta Pkwy
            <br>Marietta, GA 30060
            <br>Phone: 470-578-6000
        </ol>

        <b> 2019 Kennesaw State University </b>
    </center>

    <center>
        <p>
            <B>This is a class project. <a href="http://it5443.azurewebsites.net/">link to this class </a></B>
        </p>
    </center>
    </footer>