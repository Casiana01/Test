<!DOCTYPE html>
<html>

<head>

    <head>

        <body>
            <meta charset="utf-8">
            <title>Evaluation</title>
            <link rel="stylesheet" type="text/css" href="style.css">

    </head>

    <body>
        <center>
            <font size="20" color="black">Center for Applied Research in Information Technology</font>
        </center>

        <meta charset="utf-8">
        <div class="topnav">
            <a class="active" href="index.html">Home</a>
            <a href="faculty.php">About</a>
            <a href="events.php">Events</a>
            <a href="evaluation.php">Evaluation</a>


        </div>



    </body>



    <body>
        <style>
            ul.b {
                list-style-type: square;
            }
        </style>
        <h1>
            <p>
                <center>
                    <a href="https://ccse.kennesaw.edu/it/ "><img src="Preview Image.jpg " width="200" height="200 "> </a>
                </center>
            </p>
        </h1>


        <p>There are four positios available. Two for undergraduate students and two for graduate students:</p>
        <ul class="a">
            <li>Positions one are based on database research (Undergraduate and Graduate level).</li>
            <li>Positions two are based on analaytical and statistical research (undergraduate and graduate levels).

            </li>

        </ul>


        <title>Evaluation</title>
        <script type="text/javascript">
            function displayCourse() {

                var status = document.getElementById('status').value;
                var position = document.getElementById('position').value;

                if (status == 'Undergraduate' && position == 'Position 1') {
                    var option1 = document.getElementById('option1');
                    option1.style.display = "block";

                    var option2 = document.getElementById('option2');
                    option2.style.display = "none";

                    var option3 = document.getElementById('option3');
                    option3.style.display = "none";

                    var option4 = document.getElementById('option4');
                    option4.style.display = "none";
                } else if (status == 'Undergraduate' && position == 'Position 2') {
                    var option1 = document.getElementById('option1');
                    option1.style.display = "none";

                    var option2 = document.getElementById('option2');
                    option2.style.display = "block";

                    var option3 = document.getElementById('option3');
                    option3.style.display = "none";

                    var option4 = document.getElementById('option4');
                    option4.style.display = "none";

                } else if (status == 'Graduate' && position == 'Position 1')

                {
                    var option1 = document.getElementById('option1');
                    option1.style.display = "none";

                    var option2 = document.getElementById('option2');
                    option2.style.display = "none";

                    var option3 = document.getElementById('option3');
                    option3.style.display = "block";

                    var option4 = document.getElementById('option4');
                    option4.style.display = "none";

                } else if (status == 'Graduate' && position == 'Position 2') {
                    var option1 = document.getElementById('option1');
                    option1.style.display = "none";

                    var option2 = document.getElementById('option2');
                    option2.style.display = "none";

                    var option3 = document.getElementById('option3');
                    option3.style.display = "none";

                    var option4 = document.getElementById('option4');
                    option4.style.display = "block";
                }
            }

            function convertnumeric(grade) {

                if (grade == 'Grade A' || grade == 'a') return 4.0;
                else if (grade == 'Grade B' || grade == 'b') return 3.0;
                else if (grade == 'Grade C' || grade == 'c') return 3.0;
                else if (grade == 'Grade D' || grade == 'd') return 2.0;
                else return 0;
            }

            function Cal_Avg() {

                var status = document.getElementById('status').value;
                var position = document.getElementById('position').value;

                if (status == 'Undergraduate' && position == 'Position 1') {
                    var course1grade = document.getElementById("position1course1Grade").value;
                    var position1 = convertnumeric(course1grade);
                    var course2grade = document.getElementById("position1course2Grade").value;
                    var position2 = convertnumeric(course2grade);
                    var course3grade = document.getElementById("position1course3Grade").value;
                    var position3 = convertnumeric(course3grade);
                    var course4grade = document.getElementById("position1course4Grade").value;
                    var position4 = convertnumeric(course4grade);
                    var average = (position1 + position2 + position3 + position4) / 4;
                    var message = "<p>Your overall GPA is: " + average + "</p>";
                    document.getElementById("gpa").innerHTML = message;

                    if (average < 3.2) {
                        document.getElementById("result").innerHTML = 'Thank you for your interest, but you are not eligible to apply for this position.';
                    } else {
                        document.getElementById("result").innerHTML = 'Congratulations! You are eligible to apply for the position. Click link below to complete the application process. </br></br><a href="Form.php"><b>Online Application Form</b></a> ';
                    }
                } else if (status == 'Undergraduate' && position == 'Position 2') {

                    var course1grade = document.getElementById("position2course1Grade").value;
                    var position1 = convertnumeric(course1grade);
                    var course2grade = document.getElementById("position2course2Grade").value;
                    var position2 = convertnumeric(course2grade);
                    var course3grade = document.getElementById("position2course3Grade").value;
                    var position3 = convertnumeric(course3grade);
                    var course4grade = document.getElementById("position2course4Grade").value;
                    var position4 = convertnumeric(course4grade);
                    var average = (position1 + position2 + position3 + position4) / 4;
                    var message = "<p>Your overall GPA is: " + average + "</p>";
                    document.getElementById("gpa").innerHTML = message;

                    if (average < 3.2) {
                        document.getElementById("result").innerHTML = 'Thank you for your interest, but you are not eligible to apply for this position.';
                    } else {
                        document.getElementById("result").innerHTML = 'Congratulations! You are eligible to apply for the position. Click link below to complete the application process. </br></br><a href="Form.html"><b>Online Application Form</b></a> ';
                    }
                } else if (status == 'Graduate' && position == 'Position 1') {

                    var course1grade = document.getElementById("position3course1Grade").value;
                    var position1 = convertnumeric(course1grade);
                    var course2grade = document.getElementById("position3course2Grade").value;
                    var position2 = convertnumeric(course2grade);
                    var course3grade = document.getElementById("position3course3Grade").value;
                    var position3 = convertnumeric(course3grade);
                    var course4grade = document.getElementById("position3course4Grade").value;
                    var position4 = convertnumeric(course4grade);
                    var average = (position1 + position2 + position3 + position4) / 4;
                    var message = "<p>Your overall GPA is: " + average + "</p>";
                    document.getElementById("gpa").innerHTML = message;


                    if (average < 3.7) {
                        document.getElementById("result").innerHTML = 'Thank you for your interest, but you are not eligible to apply for this position.';
                    } else {
                        document.getElementById("result").innerHTML = 'Congratulations! You are eligible to apply for the position. Click link below to complete the application process. </br></br><a href="Form.html"><b>Online Application Form</b></a> ';
                    }
                } else if (status == 'Graduate' && position == 'Position 2') {

                    var course1grade = document.getElementById("position4course1Grade").value;
                    var position1 = convertnumeric(course1grade);
                    var course2grade = document.getElementById("position4course2Grade").value;
                    var position2 = convertnumeric(course2grade);
                    var course3grade = document.getElementById("position4course3Grade").value;
                    var position3 = convertnumeric(course3grade);
                    var course4grade = document.getElementById("position4course4Grade").value;
                    var position4 = convertnumeric(course4grade);
                    var average = (position1 + position2 + position3 + position4) / 4;
                    var message = "<p>Your overall GPA is: " + average + "</p>";
                    document.getElementById("gpa").innerHTML = message;


                    if (average < 3.7)

                    {
                        document.getElementById("result").innerHTML = 'Thank you for your interest, but you are not eligible to apply for this position.';
                    } else {
                        document.getElementById("result").innerHTML = 'Congratulations! You are eligible to apply for the position. Click link below to complete the application process. </br></br><a href="Form.html"><b>Online Application Form</b></a> ';
                    }
                }
            }
        </script>
        <div class="container">
            <div id="container">
            </div>
            <article>

                <p></p>
                <b>Please select the information: </b>
                <p>
                    <b>Student Status: </b>
                    <select name="select_status" id="status" onchange="Course()">
   <option selected> Please Select </option>
   <option> Undergraduate </option>
   <option> Graduate </option>
</select>
                </p>


                <p>
                    <b>Position: </b>
                    <select name="select_position" id="position" onchange="displayCourse()">
   <option selected>Please Select</option>
   <option> Position 1 </option>
   <option> Position 2 </option>
</select>
                </p>
                <p></p>

                <form id="option1" style="display: block;">
                    <b>Undergraduate Position 1</b>
                    <p></p>

                    Course 1: CSE 3203 Mobile System Overview

                    <select id="position1course1Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>   
   </select>
                    <br>

                    <p></p>

                    Course 2: IT 4213 Mobile Web Development

                    <select id="position1course2Grade">   
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>

                    <p></p>

                    Course 3: IT 3203 - Introduction to Web Development
                    <select id="position1course3Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option> 
   </select>
                    <br>

                    <p></p>

                    Course 4: IT 4323 - Data Communications & Networking


                    <select id="position1course4Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>

                </form>
                <p></p>

                <form id="option2" style="display: none;">
                    <b>Undergraduate Position 2</b>
                    <p></p>

                    Course 1: IT 4490 - Special Topics in Information Technology


                    <select id="position2course1Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>
                    <p></p>

                    Course 2: CSE 1321 Programming & Problem Solving II

                    <select id="position2course2Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>
                    <p></p>

                    Course 3: IT 4673 - Virtual IT Systems
                    <select id="position2course3Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>
                    <p></p>

                    Course 4:IT 4490 - Special Topics in Information Technology


                    <select id="position2course4Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option> 
   </select>
                    <br>
                    <p></p>
                </form>
                <p></p>
                <p></p>
                <form id="option3" style="display: none;">
                    <b>Graduate Position 1</b>
                    <p></p>

                    Course 1: IT 6823 Info Security Concepts Admin

                    <select id="position3course1Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>
                    <p></p>

                    Course 2: IT 6713 Business Intelligence

                    <select id="position3course2Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>
                    <p></p>

                    Course 3: IT 6713 - Business Intelligence Systems

                    <select id="position3course3Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option> 
   </select>
                    <br>
                    <p></p>

                    Course 4: IT 6423 - IT System Acquisition & Integration


                    <select id="position3course4Grade">  
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>    
   </select>
                    <br>

                </form>
                <p></p>
                <p></p>
                <form id="option4" style="display: none;">
                    <b>Graduate Position 2</b>
                    <p></p>
                    Course 1: IT 6733 - Database Administration

                    <select id="position4course1Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option>   
   </select>
                    <br>
                    <p></p>

                    Course 2: IT 6823 - Information Security Concepts & Administration

                    <select id="position4course2Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option>
   <option> Grade F </option>   
   </select>
                    <br>
                    <p></p>

                    Course 3: IT 6103 IT Policy and Law

                    <select id="position4course3Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option>   
   </select>
                    <br>
                    <p></p>

                    Course 4: IT 6843 - Ethical Hacking: Network Security and Penetration Testing

                    <select id="position4course4Grade"> 
   <option> Grade A </option> 
   <option> Grade B </option> 
   <option> Grade C </option>
   <option> Grade D </option> 
   <option> Grade F </option> 
   </select>
                    <br>

                </form>
                <p></p>
            </article>
            <script>
                var option1 = document.getElementById('option1');
                option1.style.display = "none";
                var option2 = document.getElementById('option2');
                option2.style.display = "none";
                var option3 = document.getElementById('option3');
                option3.style.display = "none";
                var option4 = document.getElementById('option4');
                option4.style.display = "none";
            </script>
            <article>
                <p>
                    <b>Please click: </b>
                    <input type="button" value="Calculate" onclick="Cal_Avg()">
                </p>
                <br>
                <p id="gpa">

                </p>
                <div id="result">

                    <br>
                    <br>
                </div>


                <br>
            </article>
            </form>
        </div>
    </body>
    <footer>

        <center>
            <ol>
                <br><b>Marietta Campus</b>
                <br>100 South Marietta Pkwy
                <br>Marietta, GA 30060
                <br>Phone: 470-578-6000
            </ol>

            <b> 2019 Kennesaw State University </b>
        </center>
        <center>
            <p>
                <B>This is a class project. <a href="http://it5443.azurewebsites.net/">link to this class </a></B>
            </p>
        </center>

</html>